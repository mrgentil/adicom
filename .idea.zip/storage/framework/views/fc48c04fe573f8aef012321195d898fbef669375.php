<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Nos Editions
<?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap mb-0">
            <div class="inner-baner-container"
                 style="background-image: url(<?php echo e(asset('assets/img/header_test-1.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title">Nos Editions</h1>
                    </div>
                </div>
            </div>
        </section>
        <!-- Inner Banner html end-->
        <section class="event-schedule-section">
            <div class="container">
                <?php $__currentLoopData = $editions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="first-day-schedule">
                        <div class="week-title">
                            <h5><?php echo e($edition->title); ?></h5>
                        </div>
                        <div class="first-day-routine-content">
                            <div class="first-day-routine-detail">
                                <div class="time-content">
                                    <span class="first-day-time-detail">
                                        <span class="time-title"><?php echo e($edition->formatted_created_at); ?></span>
                                        <span class="subject-title"><?php echo e($edition->place); ?></span>
                                    </span>
                                    <div class="lecture-image">
                                        <figure class="author-img">
                                            <img src="<?php echo e(asset(Voyager::image($edition->image1))); ?>"
                                                 alt="<?php echo e($edition->title); ?>">
                                        </figure>
                                        <figure class="author-img">
                                            <img src="<?php echo e(asset(Voyager::image($edition->image2))); ?>"
                                                 alt="<?php echo e($edition->title); ?>">
                                        </figure>
                                    </div>
                                </div>
                                <div class="first-day-routine-description">
                                    <h5 class="chapter-title"><?php echo e($edition->subject); ?></h5>
                                    <span class="chapter-link">
                                        <a href="<?php echo e($edition->slug_link); ?>">Voir plus..</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <!-- Event Schedule html start -->

        <!-- home event speaker section html start -->

        <section class="speaker-event-section">
            <div class="container">
                <div class="group-member">
                    <div class="row justify-content-center">
                        <h3 class="section-title">
                            SPEAKERS ET EXPERTS DES ÉDITIONS PRÉCÉDENTES
                        </h3>
                        <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speaker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4 col-sm-6 px-2 px-sm-3">
                                <div class="team-member">
                                    <figure class="team-img figure-round-border">
                                        <a href="<?php echo e($speaker->slug_link); ?>">
                                            <img src="<?php echo e($speaker->image); ?>" alt="<?php echo e($speaker->name); ?>">
                                        </a>
                                    </figure>
                                    <div class="team-member-info">
                                        <div class="team-content">
                                            <h5 class="author-name"><a
                                                    href="<?php echo e($speaker->slug_link); ?>"><?php echo e($speaker->name); ?></a></h5>
                                            <span class="author-prof"><?php echo e(Str::limit($speaker->function, 20)); ?></span>
                                        </div>
                                        <div class="social-icon">
                                            <ul>
                                                <?php if($speaker['facebook']): ?>
                                                    <li><a href="<?php echo e($speaker['facebook']); ?>" target="_blank"><i
                                                                class="fab fa-facebook-f"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($speaker['twitter']): ?>
                                                    <li><a href="<?php echo e($speaker['twitter']); ?>" target="_blank"><i
                                                                class="fab fa-twitter"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($speaker['instagram']): ?>
                                                    <li><a href="<?php echo e($speaker['instagram']); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                                <?php endif; ?>

                                                    <?php if($speaker['linkedIn']): ?>
                                                        <li><a href="<?php echo e($speaker['linkedIn']); ?>" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                                                    <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </section>
        <!-- reservation and booking section -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/editions/index.blade.php ENDPATH**/ ?>