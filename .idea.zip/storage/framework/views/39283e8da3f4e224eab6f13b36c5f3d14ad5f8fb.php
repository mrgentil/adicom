<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> FAQ
<?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap">
            <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/img/Layer-45.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title">FAQ</h1>
                    </div>
                </div>
            </div>
        </section>
        <!-- faq html start -->
        <div class="faq-page-section">
            <div class="container">
                <div class="faq-page-container">
                    <div class="row align-items-center">
                        <div class="col-lg-12">
                            <div class="section-head">
                                <span class="section-sub-title ">FAQ</span>
                                <h3 class="section-title">
                                    QUESTIONS GLOBALES!!
                                </h3>
                                <p class="section-paragraph">
                                    ADICOMDAYS
                                </p>
                            </div>
                            <div id="accordion-tab-one" class="accordion-content" role="tablist">
                                <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div id="accordion-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="accordion-A">
                                    <div class="card-header" role="tab" id="qus-A">
                                        <h6 class="mb-0">
                                            <a data-bs-toggle="collapse" href="#collapse-one" aria-expanded="true" aria-controls="collapse-one">
                                                <?php echo e($faq->question); ?>

                                            </a>
                                        </h6>
                                    </div>
                                    <div id="collapse-one" class="collapse show" data-bs-parent="#accordion-tab-one" role="tabpanel" aria-labelledby="qus-A">
                                        <div class="card-body">
                                            <?php echo e($faq->answer); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/faq/index.blade.php ENDPATH**/ ?>