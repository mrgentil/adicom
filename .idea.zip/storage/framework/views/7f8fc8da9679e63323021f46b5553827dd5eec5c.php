<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Editions : <?php echo e($editions->title); ?> <?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap">
            <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/img/header_test-1.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title"><?php echo e($editions->title); ?></h1>
                    </div>
                </div>
            </div>
        </section>
        <!-- event deatil html start-->
        <section class="event-detail-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 primary">
                        <div class="right-sidebar">
                            <figure class="post-thumb">
                                <a href="<?php echo e($editions->slug_link); ?>"><img src="<?php echo e(asset(Voyager::image($editions->image1))); ?>" alt="<?php echo e($editions->title); ?>"></a>
                            </figure>
                            <div class="single-event-content-wrap">
                                <h4>
                                    <?php echo e($editions->title); ?>

                                </h4>
                                <p>
                                    <?php echo e($editions->subject); ?>

                                </p>
                            </div>
                            <div class="keypoint-inner">
                                <div class="key-point-list">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="item-list">
                                                <ul>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->visitor); ?> Visiteurs
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->speakers_experts); ?> Intervenants & experts
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->panels_keynotes); ?> Panels & keynotes
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->exclusive_study); ?> Étude exclusive
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->influencers); ?> Influenceurs récompensés
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->day_of_meetings); ?> Journée de rendez-vous BtoB
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->connections); ?> Connections
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                +<?php echo e($editions->interaction_live); ?> Interactions durant le live
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                               +<?php echo e($editions->create_content); ?> Candidatures de créateurs de contenus
                                                            </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="item-list">
                                                <ul>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                              <?php echo e($editions->influencers); ?> Influenceurs récompensés
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->masterclass); ?> Masterclass
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->side_event); ?> Side Event avec Wil Aime
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->nationalities_represented); ?> Nationalités représentées
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->formations); ?> Apprenants sur 3 campus
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                +<?php echo e($editions->gust_vip); ?>  Invités VIP présents
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                +<?php echo e($editions->person_connected); ?> Personnes connectées sur le live
                                                            </span>
                                                    </li>
                                                    <li>
                                                        <i aria-hidden="true" class="fas fa-dot-circle"></i>
                                                        <span>
                                                                <?php echo e($editions->anniv_ceremonie); ?> Cérémonie anniversaire
                                                            </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 secondary">
                        <div class="sidebar">
                            <aside class="widget author_widget">
                                <div class="widget-content text-center">
                                    <div class="profile">
                                        <figure class="post-thumb">
                                            <a href="<?php echo e(asset(Voyager::image($editions->image2))); ?>"><img src="<?php echo e(asset(Voyager::image($editions->image2))); ?>" alt="<?php echo e($editions->title); ?>"></a>
                                        </figure>
                                    </div>
                                </div>
                            </aside>
                            <aside class="event-info-package widget">
                                <h6 class="title-divider-center">EVENT INFORMATION</h6>
                                <div class="event-time-detail">
                                    <ul>
                                        <li>
                                            <i aria-hidden="true" class="far fa-calendar-alt"></i>
                                            <?php echo e($editions->formatted_created_at); ?>

                                        </li>

                                        <li>
                                            <i aria-hidden="true" class="far fa-building"></i>
                                            <?php echo e($editions->place); ?>

                                        </li>
                                    </ul>
                                </div>
                            </aside>
                            <aside class="widget extra-event">
                                <div class="overlay"></div>
                                <h6 class="title-divider-center">3 Dernières Editions</h6>
                                <div class="event-list">
                                    <ul>
                                        <?php $__currentLoopData = $latest_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <h6>
                                                    <a href="<?php echo e($latest_event->slug_link); ?>"><?php echo e($latest_event->title); ?></a>
                                                </h6>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Event detail html start -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/editions/show.blade.php ENDPATH**/ ?>