<?php $__env->startComponent('mail::message'); ?>
    # Nouveau message de contact

    **Nom :** <?php echo e($data['name']); ?>


    **Email :** <?php echo e($data['email']); ?>


    **Sujet :** <?php echo e($data['subject']); ?>


    **Téléphone :** <?php echo e($data['phone']); ?>


    **Message :**
    <?php echo e($data['contenu']); ?>


    Merci,

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\adicomDays\resources\views/mail/contact.blade.php ENDPATH**/ ?>