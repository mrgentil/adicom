<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Speaker : <?php echo e($speakers->name); ?> <?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap">
            <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/img/header_test-1.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title"><?php echo e($speakers->name); ?></h1>
                    </div>
                </div>
            </div>
        </section>
        <!-- event deatil html start-->
        <!-- event speaker detail section html start -->
        <section class="speaker-detail-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 secondary">
                        <div class="sidebar">
                            <aside class="author_widget">
                                <div class="widget-content text-center">
                                    <div class="profile">
                                        <figure class="avatar">
                                            <img src="<?php echo e($speakers->image); ?>" alt="<?php echo e($speakers->name); ?>">
                                        </figure>
                                        <div class="text-content">
                                            <h5 class="name-title">
                                                <?php echo e($speakers->name); ?>

                                            </h5>
                                            <span class="profession">
                                                    <?php echo e($speakers->function); ?>

                                                </span>
                                        </div>
                                        <div class="social-icon">
                                            <ul>
                                                <?php if($speakers['facebook']): ?>
                                                    <li><a href="<?php echo e($speakers['facebook']); ?>" target="_blank"><i
                                                                class="fab fa-facebook-f"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($speakers['twitter']): ?>
                                                    <li><a href="<?php echo e($speakers['twitter']); ?>" target="_blank"><i
                                                                class="fab fa-twitter"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($speakers['instagram']): ?>
                                                    <li><a href="<?php echo e($speakers['instagram']); ?>" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                                <?php endif; ?>

                                                <?php if($speakers['linkedIn']): ?>
                                                    <li><a href="<?php echo e($speakers['linkedIn']); ?>" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                        </div>
                    </div>
                    <div class="col-lg-8 primary">
                        <div class="cv-container">
                            <div class="biography-wrapper">
                                <?php if($speakers['biography']): ?>
                                    <h5 class="title-divider">
                                        BIOGRAPHIE
                                    </h5>
                                    <p>
                                        <?php echo $speakers['biography']; ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/editions/speaker.blade.php ENDPATH**/ ?>