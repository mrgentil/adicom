<?php $__env->startSection('title'); ?> <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> Médias : <?php echo e($medias->title); ?> <?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap single-blog-inner-banner-wrap">
            <div class="inner-baner-container" style="background-image: url(<?php echo e(asset('assets/img/test3.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title"><?php echo e($medias->title); ?></h1>
                        <div class="entry-meta">
                                <span class="byline">
                                    <a href="blog-archive.html">
                                    <?php if($medias->user): ?>
                                            <?php echo e($medias->user->name); ?>

                                        <?php else: ?>
                                            Aucun utilisateur associé
                                        <?php endif; ?>

                                    </a>
                                </span>
                            <span class="posted-on">
                                    <a href="#"><?php echo e($medias->formatted_created_at); ?></a>
                                </span>
                            <span class="comments-link">
                                    <a href="#commentArea"><?php echo e(count($medias->comments)); ?> Commentaires</a>
                                </span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- single page section html start -->
        <section class="single-post-section">
            <div class="single-post-inner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 primary">
                            <div class="right-sidebar">
                                <!-- single blog post html start -->
                                <figure class="feature-image figure-round-border">
                                    <img src="<?php echo e($medias->image); ?>" alt="<?php echo e($medias->title); ?>">
                                </figure>
                                <div class="single-content-wrap">
                                    <p>
                                        <?php echo $medias->body; ?>

                                    </p>
                                </div>
                                <div class="post-socail-wrap">
                                    <div class="social-icon-wrap">
                                        <div class="social-icon social-facebook">
                                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($medias->url)); ?>" target="_blank" rel="noopener noreferrer">
                                                <i class="fab fa-facebook"></i>
                                                <span>Facebook</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-whatsapp">
                                            <a href="whatsapp://send?text=<?php echo e(urlencode($medias->url)); ?>" target="_blank" rel="noopener noreferrer">
                                                <i class="fab fa-whatsapp"></i>
                                                <span>Whatsapp</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-twitter">
                                            <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode($medias->url)); ?>&text=<?php echo e(urlencode($medias->title)); ?>" target="_blank" rel="noopener noreferrer">
                                                <i class="fab fa-twitter"></i>
                                                <span>Twitter</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-linkedin">
                                            <a href="https://www.linkedin.com/shareArticle?url=<?php echo e(urlencode($medias->url)); ?>&title=<?php echo e(urlencode($medias->title)); ?>" target="_blank" rel="noopener noreferrer">
                                                <i class="fab fa-linkedin"></i>
                                                <span>Linkedin</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- divider line html -->
                                <div class="divider-line">
                                    <span class="st-line"></span>
                                </div>
                                <!-- post comment html -->








































                                <!-- blog post item html end -->
                            </div>
                        </div>
                        <div class="col-lg-4 secondary">
                            <div class="sidebar">
                                <aside class="widget search-widget">
                                    <form class="search-form">
                                        <input type="text" name="search" placeholder="Search..">
                                        <button class="search-btn">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </form>
                                </aside>
                                <aside class="widget author_widget">
                                    <h6 class="widget-title-divider-center-bottom">À PROPOS DE L'ORGANISATEUR</h6>
                                    <div class="widget-content text-center">
                                        <div class="profile">
                                            <figure class="avatar">
                                                <img src="<?php echo e(asset('assets/img/thumb-organization-1663026283-LgqXo.png')); ?>" alt="">
                                            </figure>
                                            <div class="text-content">
                                                <h5 class="name-title">
                                                    Totem Experience
                                                </h5>
                                                <p class="author-info">
                                                    Créativité gigitale & storytelling au service des africans , pour un plus bel impact
                                                    auprès de leur communauté.
                                                </p>
                                            </div>
                                            <div class="social-icon">
                                                <ul>
                                                    <li>
                                                        <a target="_blank" href="https://web.facebook.com/Totemexperience/?_rdc=1&_rdr">
                                                            <i class="fab fa-facebook-f"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a target="_blank" href="https://www.linkedin.com/company/totem-experience/">
                                                            <i class="fab fa-linkedin"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a target="_blank" href="https://twitter.com/totemfactory/">
                                                            <i class="fab fa-twitter"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a target="_blank" href="https://www.instagram.com/totemexperience/">
                                                            <i class="fab fa-instagram"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </aside>
                                <aside class="widget widget_latest_post widget-post-thumb">
                                    <div class="text-center">
                                        <h6 class="widget-title-divider-center-bottom">Médias en rélations</h6>
                                    </div>
                                    <ul>
                                        <?php $__currentLoopData = $related_medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <figure class="post-thumb">
                                                    <a href="<?php echo e($item->slug_link); ?>"><img src="<?php echo e($item->image); ?>" alt="<?php echo e($item->title); ?>"></a>
                                                </figure>
                                                <div class="post-content">
                                                    <h6>
                                                        <a href="<?php echo e($item->slug_link); ?>"><?php echo e($item->title); ?></a>
                                                    </h6>
                                                    <div class="entry-meta">
                                                        <span class="posted-on">
                                                            <a href="<?php echo e($item->slug_link); ?>"><?php echo e($item->formatted_created_at); ?></a>
                                                        </span>
                                                        <span class="comments-link">
                                                            <a href="<?php echo e($item->slug_link); ?>"><?php echo e(count($item->comments)); ?> Commentaires</a>
                                                        </span>
                                                    </div>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </aside>
                                <aside class="widget widget_video">
                                    <div class="text-center">
                                        <h6 class="widget-title-divider-center-bottom">A la une</h6>
                                    </div>
                                    <div class="video-wrapper">
                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/4UvSbQ5gkKE" title="YouTube video player"
                                                frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media;
                                         gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>


                                    </div>
                                </aside>
                                <aside class="widget widget_social">
                                    <div class="text-center">
                                        <h6 class="widget-title-divider-center-bottom">Suivez-nous sur</h6>
                                    </div>
                                    <div class="social-icon-wrap">
                                        <div class="social-icon ">
                                            <a href="https://web.facebook.com/AdicomDays?_rdc=1&_rdr">
                                                <i class="fab fa-facebook"></i>
                                                <span>Facebook</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-pinterest">
                                            <a href="https://www.instagram.com/adicomdays/">
                                                <i class="fab fa-instagram"></i>
                                                <span>Instagram</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-whatsapp">
                                            <a href="https://www.youtube.com/channel/UC3EJNtj43Kete9tz7Bsa1aQ">
                                                <i class="fab fa-youtube"></i>
                                                <span>Youtube</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-linkedin">
                                            <a href="https://www.linkedin.com/company/adicom-days/">
                                                <i class="fab fa-linkedin"></i>
                                                <span>Linkedin</span>
                                            </a>
                                        </div>
                                        <div class="social-icon social-twitter">
                                            <a href="https://twitter.com/adicomdays">
                                                <i class="fab fa-twitter"></i>
                                                <span>Twitter</span>
                                            </a>
                                        </div>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/medias/show.blade.php ENDPATH**/ ?>