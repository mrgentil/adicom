<?php $__env->startSection('title'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('title'); ?> ADICOM ACADEMY
<?php $__env->stopSection(); ?>













<?php $__env->startSection('content'); ?>
    <main id="content" class="site-main">
        <!-- Inner Banner html start-->
        <section class="inner-banner-wrap">
            <div class="inner-baner-container"
                 style="background-image: url(<?php echo e(asset('assets/img/header_test-1.jpg')); ?>);">
                <div class="container">
                    <div class="inner-banner-content">
                        <h1 class="inner-title">ADICOM ACADEMY</h1>
                    </div>
                </div>
            </div>
        </section>
        <!-- Inner Banner html end-->
        <section class="about-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="section-head">
                            <h3 class="section-title">
                                BOOTCAMP ADICOMACADEMY
                                La formation en présentiel pour
                                booster votre stratégie digitale
                            </h3><br><br>
                            <p class="text-center">Améliorez les performances de vos campagnes sur les réseaux
                                sociaux</p>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="section-head">
                            <p class="section-paragraph">
                            <h5 class="section-title">À PROPOS DU BOOTCAMP</h5>
                            <p>À travers nos cours et de la pratique avec nos experts certifiés, vous pourrez :</p><br>

                            <li>Définir vos objectifs,</li>
                            <br><br>
                            <li>Construire pas à pas votre plan d’action sur vos plateformes sociales.</li>
                            <br>
                            <p>
                                Un savant mélange de storytelling, contenus, nouveaux formats, influence marketing pour
                                apporter <strong>le bon message aux bonnes cibles et au bon moment !</strong>
                            </p>

                            <strong>
                                Il s’agit d’un programme accéléré qui transforme et donne des clés pour booster &
                                implémenter sa stratégie de marketing digital sur les marchés d’Afrique francophone.
                            </strong>
                            <br><br><br>

                            <h5 class="section-title">OBJECTIFS PÉDAGOGIQUES </h5>
                            <p>
                                À la fin de cette formation, vous serez capable de : <br>
                            </p>

                            <li>Définir une stratégie et un plan d’actions pour votre stratégie social media</li>
                            <br>
                            <li>Raconter une histoire qui résonne avec votre audience</li>
                            <br>
                            <li>Créer et animer une communauté</li>
                            <br>
                            <li>Créer du contenu efficace et engageant</li>
                            <br>
                            <li>Définir et alimenter un planning éditorial</li>
                            <br>
                            <li>Mesurer et optimiser les performances de vos publications</li>
                            <br>
                            <li>Identifier, collaborer, et créer du contenu avec des influenceurs pertinents</li>
                            <br>
                        </div>
                    </div>
                </div>
                
                <div class="iconbox-container-bg">
                    <div class="iconbox-item-bg">
                        <div class="iconbox-content-bg">
                            <img src="<?php echo e(asset('assets/img/benedicte-e1651741666840.png')); ?>" alt="" class="img-fluid rounded-circle" style="max-width: 100px;">
                            <h5>Bénédicte Gallet</h5>
                            <p>Ex-Directrice Mediacom Burkina Faso</p>
                            <p>L'avantage c'est qu'on était un petit groupe. Cela a permis à chacun d'avoir un
                                rapport particulier, personnel, avec le formateur.</p>
                        </div>
                    </div>
                    <div class="iconbox-item-bg">
                        <div class="iconbox-content-bg">
                            <img src="<?php echo e(asset('assets/img/steve-e1651742174538.png')); ?>" alt="" class="img-fluid rounded-circle" style="max-width: 100px;">
                            <h5>Stève Fayomi</h5>
                            <p>Manager senior Orange Côte d'Ivoires</p>
                            <p>Mention "excellent" ! On attend la prochaine formation avec impatience.</p>
                        </div>
                    </div>
                    <div class="iconbox-item-bg item-3">
                        <div class="iconbox-content-bg ">
                            <img src="<?php echo e(asset('assets/img/rebecca-e1651743072900.jpg')); ?>" alt="" class="img-fluid rounded-circle" style="max-width: 100px;">
                            <h5>Rebecca N'Guessan</h5>
                            <p>Chef de projet chez Kaizene</p>
                            <p>Le formateur a été très professionnel, on voit tout de
                                suite que c'est quelqu'un qui maîtrise son sujet.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="about-mission-and-aim">
            <div class="container">
                <div class="about-purpose">
                    <figure class="about-banner-image">
                        <div class="pattern-overlay overlay-circle"></div>
                        <img src="assets/img/eventum-img38.png" alt="">
                    </figure>
                    <div class="mission-and-aim-inside">
                        <div class="about-mission-content">
                            <div class="section-head">
                                <span class="section-sub-title ">INTRODUCTION</span>
                                <h3 class="section-title">
                                    ABOUT OUR WORKSHOP
                                </h3>
                                <p class="section-paragraph">
                                    Consequat sociosqu sem officiis aute ridiculus repellat in aliquip at, metus
                                    sociosqu veritatis cubilia ac soluta? Faucibus ipsam, incidunt cras.
                                </p>
                            </div>
                            <div class="widget-bg faq-widget">
                                <div id="sidebar-tab-content" class="accordion-content" role="tablist">
                                    <div id="accordion-A" class="card tab-pane fade show active" role="tabpanel"
                                         aria-labelledby="accordion-A">
                                        <div class="card-header" role="tab" id="qus-A">
                                            <h6 class="mb-0">
                                                <a data-bs-toggle="collapse" href="#collapse-one" aria-expanded="false"
                                                   aria-controls="collapse-one" class="collapsed">
                                                    LEARN FROM THE BEST IN INDUSTRY!
                                                </a>
                                            </h6>
                                        </div>
                                        <div id="collapse-one" class="collapse" data-bs-parent="#sidebar-tab-content"
                                             role="tabpanel" aria-labelledby="qus-A">
                                            <div class="card-body">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus,
                                                luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                            </div>
                                        </div>
                                    </div>
                                    <div id="accordion-B" class="card tab-pane" role="tabpanel"
                                         aria-labelledby="accordion-B">
                                        <div class="card-header" role="tab" id="qus-B">
                                            <h6 class="mb-0">
                                                <a class="collapsed" data-bs-toggle="collapse" href="#collapse-two"
                                                   aria-expanded="false" aria-controls="collapse-two">
                                                    OUR SPEAKER EXPERIENCE IN THIS EVENT
                                                </a>
                                            </h6>
                                        </div>
                                        <div id="collapse-two" class="collapse" data-bs-parent="#sidebar-tab-content"
                                             role="tabpanel" aria-labelledby="qus-B">
                                            <div class="card-body">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus,
                                                luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                            </div>
                                        </div>
                                    </div>
                                    <div id="accordion-C" class="card tab-pane" role="tabpanel"
                                         aria-labelledby="accordion-C">
                                        <div class="card-header" role="tab" id="qus-C">
                                            <h6 class="mb-0">
                                                <a class="collapsed" data-bs-toggle="collapse" href="#collapse-three"
                                                   aria-expanded="false" aria-controls="collapse-three">
                                                    IMPROVE YOUR BUSINESS KOWLEDGE
                                                </a>
                                            </h6>
                                        </div>
                                        <div id="collapse-three" class="collapse" data-bs-parent="#sidebar-tab-content"
                                             role="tabpanel" aria-labelledby="qus-C">
                                            <div class="card-body">
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus,
                                                luctus nec ullamcorper mattis, pulvinar dapibus leo.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- About page html start -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\adicomDays\resources\views/adicom/academy.blade.php ENDPATH**/ ?>