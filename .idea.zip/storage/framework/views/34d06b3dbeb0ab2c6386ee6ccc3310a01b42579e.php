<div class="main-navigation col-lg-9 justify-content-between d-flex align-items-center">
    <nav id="navigation" class="navigation d-none d-lg-inline-block">
        <ul>
            <li class="current-menu-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/')); ?>">Accuiel</a>
            </li>
            <li class="menu-item-has-children">
                <a href="#">ADICOM</a>
                <ul>
                    <li class="<?php echo e(Request::is('adicom-academy') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('adicom.academie')); ?>">ADICOM ACADEMY </a>
                    </li>
                    <li class="<?php echo e(Request::is('adicom-awards') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('adicom.awards')); ?>">ADICOM AWARDS</a>
                    </li>
                    <li class="<?php echo e(Request::is('adicom-forum') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('adicom.forum')); ?>">ADICOM FORUM</a>
                    </li>
                    <li class="<?php echo e(Request::is('adicom-4-good') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('adicom.good')); ?>">ADICOM 4 GOOD</a>
                    </li>
                    <li class="<?php echo e(Request::is('adicom-watch') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('adicom.watch')); ?>">ADICOM WATCH</a>
                    </li>
                </ul>
            </li>
            <li class="<?php echo e(Request::is('editions') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('edition.index')); ?>">Editions</a>
            </li>
            <li class="<?php echo e(Request::is('medias') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('media.index')); ?>">Médias</a>
            </li>
            <li class="<?php echo e(Request::is('faq') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('faqs.index')); ?>">FAQ</a>
            </li>
            <li class="<?php echo e(Request::is('contact-us') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('contact.index')); ?>">Contact</a>
            </li>
        </ul>
    </nav>
    <div class="header-btn d-inline-block <?php echo e(Request::is('booking') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('booking.index')); ?>" class="button-round-primary">ACHETER BILLET</a>
    </div>
</div>
<?php /**PATH C:\laragon\www\adicomDays\resources\views/partials/nav.blade.php ENDPATH**/ ?>